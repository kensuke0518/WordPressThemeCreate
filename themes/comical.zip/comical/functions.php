<?php
get_template_part('functions/admin');
get_template_part('functions/post');
get_template_part('functions/javascript');
get_template_part('functions/shortcode');
?>